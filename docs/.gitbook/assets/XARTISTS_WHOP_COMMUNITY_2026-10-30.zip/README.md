# xArtists — lien communautaire Whop vérifié

Vérification du 30 octobre 2026, 15:07–15:09 Europe/Paris.

La page https://whop.com/xartists-9352/ répond HTTP 200, titre « xArtists | Whop ». Le catalogue public https://whop.com/xartists-9352/products répond HTTP 200 et indique qu'aucun produit n'est actuellement disponible au public. L'accueil contient des liens X et YouTube ; aucune offre payante, aucun prix et aucun accès acheté n'ont été attestés. Le bouton Join n'a pas été actionné.

## Changement prêt à relire

Trois fichiers, cinq lignes ajoutées : URL Whop centralisée dans LINKS, lien Whop externe dans le footer, et canal Whop dans la présentation GitBook. Ce lien ouvre la communauté. Il ne raccorde pas le paiement ni les droits d'accès Whop à xArtists.

Base : `32d31b96ded168124e92fe8064b0ff94c6f11dcc`. Candidat local : `c3a1c3d84a6bf6070096ea06b61628438faa58f9`.

GitHub refuse la création de branche avec HTTP 403 « Resource not accessible by integration » ; la relecture de la ref renvoie 404. Aucune branche distante, PR, fusion ou publication de ce correctif n'a été effectuée.

## Validation locale

40 tests frontend, build Vite, validation des 99 routes, huit traductions complètes et 64 rendus serveur : OK. Le build de vérification a utilisé LIA paper (0), carte masquée (false), comme garde-fous locaux. Ce correctif ne modifie aucun flag du workflow public ; l'alignement LIA B reste une livraison séparée.

## Application par l'opérateur disposant de l'écriture

Respecter la priorité P0 de Nelson : smoke Paybox Verifone réel puis alignement LIA B, avant la mise en ligne du lien communautaire Whop. Dans un checkout propre de main, créer une branche de revue et vérifier le patch avant application :

```sh
git switch -c feat/whop-community-link-20261030
git apply --check /chemin/whop-community.patch
git apply /chemin/whop-community.patch
git diff --check
```

Relire les trois fichiers, exécuter les contrôles frontend, puis ouvrir une PR. Les sources complètes sont fournies pour comparaison ; ne pas écraser des changements concurrents en recopiant ces fichiers sans revue.

Le mode Paybox Verifone prod n'atteste aucun paiement Whop. L'activation d'une offre et de son accès serveur nécessitera un produit/plan marchand réellement publié et une confirmation fournisseur authentifiée. Aucun endpoint, identifiant produit ou montant Whop n'est inventé dans ce lot.
