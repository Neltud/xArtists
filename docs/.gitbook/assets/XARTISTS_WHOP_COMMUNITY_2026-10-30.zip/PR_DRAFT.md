# Lier la communauté Whop xArtists depuis la dapp

La communauté Whop xArtists est publique, mais son catalogue public ne propose actuellement aucun produit. Ajouter son lien dans le footer et dans les canaux de contribution permet de la retrouver sans présenter un checkout ou des droits synchronisés comme disponibles.

Validation : 40 tests frontend, build Vite, 99 routes, huit langues et 64 rendus serveur. Livraison séparée du correctif LIA B ; mise en ligne après le P0 demandé par Nelson.
