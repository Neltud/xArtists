# P0 — LIA paper (option B) et statut PayBox

Livraison du 30 octobre 2026. Candidat local vérifié, non poussé et non déployé. La création de branche GitHub a renvoyé 403 « Resource not accessible by integration » ; sa relecture renvoie 404. Aucune PR n'est annoncée.

## Ordre strict de Nelson

1. Un seul Sentinel réel, 50 EUR, signé et payé par Nelson. Recueillir le véritable order_id, la confirmation fournisseur authentifiée, server_confirmed:true et My Packs concordant.
2. Après ce smoke, intégrer le correctif B puis rebuild/deploy Pages. Le workflow force VITE_LIA_LIVE_TRADING=0 même si une ancienne variable du dépôt vaut 1. Le badge indique paper ; un document Vellum ancien n'est plus affiché comme un état courant.
3. Publier ensuite le statut GitBook de référence. La révision #21 reste en brouillon jusque-là.
4. Fermer les entêtes HTTP Pages avec une couche qui les émet réellement. Ce lot ne migre ni domaine ni hébergeur.

## Code et revue

Le manifeste contient la base et le candidat exacts, ainsi que les empreintes des fichiers. Les sources complètes des 16 fichiers modifiés sont dans source/. Le patch complet contient code et documentation ; le patch code-only contient les huit fichiers de front/workflow pour séparer l'application du code du Git Sync documentaire.

Depuis un checkout compatible, commencer par git apply --check /chemin/p0-paper-complete.patch. Ne pas forcer l'application par-dessus les changements de Grok ou d'un autre contributeur. Une évolution de main nécessite une revue et éventuellement un rebase. Aucune commande de paiement, signature, bootstrap ou activation du host n'est incluse.

## Vérifications réalisées

44 tests frontend, 61 tests API, 7 tests Python de release, 5 contrôles de gates, build Vite paper, 99 routes, 8 langues, 64 rendus de pages et 296 rendus de modules. Le contrôle mobile passe aussi. Un avertissement existant de 127 valeurs d'affichage français/chinois identiques reste à examiner ; il n'a pas été masqué. Le premier lancement des tests API manquait de répertoire temporaire ; le lancement réussi utilise TMPDIR dans le workspace.

Les assertions du build vérifient que build-info et dapp-release portent tous deux false. Ces fichiers décrivent le build local candidat. Les fichiers servis en production restent ceux de main tant qu'aucun déploiement n'a eu lieu.

## PayBox et entêtes

Le précontrôle public constate MODE prod armé/configuré, quote Sentinel 5000 centimes au taux ops fixe 3.24, refus JWT 401 et IPN vide 400. Aucun paiement ni ordre n'est créé. Ce n'est pas le smoke réel.

CSP HTTP, XFO, nosniff et Referrer-Policy HTTP n'ont pas été observés sur Pages. Une CSP meta existe ; le candidat enlève seulement sa directive frame-ancestors sans effet et ajoute la meta referrer applicable au document. Le fichier _headers ne suffit pas à annoncer une protection HTTP effective. Les entêtes restent un point ouvert.

Révision GitBook : https://app.gitbook.com/o/KMZP0M6knXUIxNX1Dujn/s/7uFQg6p9cNvePhELkvN3/~/changes/RWExcRdvC1cRThfiLvG1/
