---
hidden: true
noIndex: true
---

# Suite logique — 30 octobre 2026

**Mise à jour P0 à 10:29 Europe/Paris :** le [statut de référence](security/prod-live-2026-10-29.md) prime sur l’instantané historique ci-dessous. PayBox MODE prod est armé ; le paiement réel reste non attesté. Option B paper préparée, non déployée. Aucun armement live de Vellum dans ce lot.

Probe 2026-10-30T05:36:00Z : epoch **2278** · EGLD **$3,21** · mcap **$99,73M** · APR **9,13 %** · LIA Ops **1.585598 EGLD** nonce **1479** · packs **10 / 5 / 2,5** · market **0,0175** · slot **0,5000** · $TRO circ **476 224** / **561** comptes · ~$0.00007902 · 2815 tx.

## Fait dans ce push (0.125.0)

* Le site se republie via `static.yml`. Ce n’est **pas** un go-live trading.
* Le repli réseau ne sert plus le 28 oct (epoch 2276, $3,37).
* La copie `/go-live` ne dit plus que les retraits Upbit sont suspendus. Au 30 oct le statut public est **retraits ouverts, dépôts bloqués, désignation toujours là**.
* Le correctif P0 force `VITE_LIA_LIVE_TRADING=0` (option B), à merger/rebuilder après le smoke selon l’ordre demandé. Le build actuellement servi reste un instantané antérieur à ce correctif.
* `VITE_PAYBOX_ENABLED` garde **false** par défaut. Render répond **prod**, configuré ; seule une vente réelle confirmée fermera le smoke. La visibilité carte est un contrôle indépendant.
* Hashes SC inchangés. Slot non payable. LIA nonce 1479.
* PR [#200](https://github.com/Neltud/xArtists/pull/200) **non mergée**.

## Ne pas faire

* Appeler ce déploiement un go-live trading parce que le drapeau user-sign est à 1, parce que les retraits Upbit sont revenus, ou parce que le site est en ligne.
* Nouveau swap / wrap / liquidité sur LIA Ops.
* Allumer le live parce que le prix est à $3,21, parce qu’une annonce FET tombe le 2–6 nov, ou parce qu’INIT est en revue.
* Modifier les secrets PayBox dans ce lot, `claimFees` ou envoyer des fonds vers des placeholders vides.
* Merger la PR #200 tant que `npm ci` n’est pas rétabli.
* `VITE_*_CODEHASH_OK=1` dans git.
* Déverrouiller « Sign & broadcast » sans brancher un `signAndSend` utilisateur et sans garde KR.
* Merger Vite 8 / ESLint 10.
* Ouvrir le slot REAL.

## Ordre seulement après un maintien publié (Upbit ou Bithumb, après le 20 nov ou plus tôt si une notice lève le warning **et** que les dépôts ne sont plus la porte fermée qu’on croit)

1. Une TX **utilisateur** sur l’explorer (1 TRO staké, ou Sentinel 2,5 EGLD, ou buy/bid listing **#2** — jamais l’id #1).
2. Un seul micro-trade ops signé xPortal, journalisé, caps `liaConfig`.
3. Inscription MX-8004 / First 100.
4. Upgrade **du même** slot en payable, puis 1 spin poussière.
5. Akash `VITE_BRAIN_WS` seulement si l’endpoint répond.
6. Paybox : une carte test preprod + IPN + My Packs sans double livraison, **puis** la variable `VITE_PAYBOX_ENABLED=true`. Le store Neon vient après, avec un lockfile complet.

## D’ici le 16–20 nov

Le travail utile est la lisibilité publique (galerie, musée, market en lecture, packs, `/go-live` honnête, repli réseau à jour) et la recette Paybox preprod. Pas de capital nouveau sur LIA Ops.
