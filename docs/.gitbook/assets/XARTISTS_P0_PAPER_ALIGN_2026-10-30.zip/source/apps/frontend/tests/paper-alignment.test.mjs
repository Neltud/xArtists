import assert from 'node:assert/strict'
import { test } from 'node:test'
import { loadSource } from './load-source.mjs'

test('paper build leaves an empty journal empty and states that LIA is not executing', () => {
  const prior = globalThis.localStorage
  const values = new Map()
  globalThis.localStorage = { getItem: key => values.get(key) || null, setItem: (key, value) => values.set(key, value) }
  try {
    const env = { VITE_LIA_LIVE_TRADING: '0' }
    const config = loadSource('src/config/liaConfig.ts', env)
    const journal = loadSource('src/lia/intentJournal.ts', env)
    assert.equal(config.LIA_LIVE_TRADING, false)
    assert.equal(config.LIA_MODE, 'paper')
    assert.match(config.LIA_BADGE, /paper/)
    assert.deepEqual(journal.loadJournal(), [])
  } finally { globalThis.localStorage = prior }
})

test('missing, malformed, future and old Vellum publications never imply a current live host', () => {
  const { vellumPublicationState: state } = loadSource('src/lia/vellumBridge.ts')
  const now = Date.parse('2026-10-30T10:00:00Z')
  assert.equal(state(null, now), 'unverified')
  assert.equal(state({ ok: true, live: true }, now), 'unverified')
  assert.equal(state({ ts: 'invalid', ok: true, live: true }, now), 'unverified')
  assert.equal(state({ ts: '2026-10-30T10:01:00Z', ok: true, live: true }, now), 'unverified')
  assert.equal(state({ ts: '2026-10-07T15:40:00Z', ok: false, live: true }, now), 'stale')
  for (const extra of [{ steps: {} }, { steps: [null] }, { summary: 'live' }, { errors: 'none' }]) {
    assert.equal(state({ ts: '2026-10-30T09:59:00Z', ok: true, live: true, ...extra }, now), 'unverified')
  }
})

test('root or nested failures override a successful live declaration', () => {
  const { vellumPublicationState: state } = loadSource('src/lia/vellumBridge.ts')
  const now = Date.parse('2026-10-30T10:00:00Z')
  const run = { ts: '2026-10-30T09:59:00Z', ok: true, live: true }
  assert.equal(state({ ...run, ok: false, summary: { ok: true } }, now), 'failed')
  assert.equal(state({ ...run, summary: { ok: false } }, now), 'failed')
  assert.equal(state({ ...run, errors: ['gate failed'] }, now), 'failed')
  assert.equal(state({ ...run, steps: [{ id: 'guardian', ok: false }] }, now), 'failed')
})

test('a fresh successful document reports a declaration, with contradictory modes rejected', () => {
  const { vellumPublicationState: state } = loadSource('src/lia/vellumBridge.ts')
  const now = Date.parse('2026-10-30T10:00:00Z')
  const run = { ts: '2026-10-30T09:59:00Z', ok: true }
  assert.equal(state({ ...run, live: false }, now), 'paper_declared')
  assert.equal(state({ ...run, summary: { mode: 'shadow' } }, now), 'paper_declared')
  assert.equal(state({ ...run, live: true }, now), 'live_declared')
  assert.equal(state({ ...run, live: true, summary: { mode: 'paper' } }, now), 'unverified')
  assert.equal(state({ ...run, ok: undefined, live: true }, now), 'unverified')
})
