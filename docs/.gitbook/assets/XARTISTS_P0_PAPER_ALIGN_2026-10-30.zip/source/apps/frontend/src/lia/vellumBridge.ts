/**
 * Read last Vellum pipeline publish (if mirrored to public/data).
 * No TX. Fail soft.
 */

export type VellumLastRun = {
  ts?: string
  ok?: boolean
  errors?: string[]
  version?: string
  live?: boolean
  chain_id?: string
  summary?: {
    mode?: string
    elapsed_ms?: number
    guardian_allow?: boolean
    failed_steps?: string[]
    ok?: boolean
  }
  steps?: { id: string; ok?: boolean; error?: string }[]
}

export type VellumPublicationState = 'unverified' | 'stale' | 'failed' | 'paper_declared' | 'live_declared'

/** A published document is evidence of its contents, not an attested host or trade. */
export function vellumPublicationState(run: VellumLastRun | null, now = Date.now()): VellumPublicationState {
  if (!run || !Number.isFinite(now)) return 'unverified'
  const timestamp = typeof run.ts === 'string' ? Date.parse(run.ts) : NaN
  if (!Number.isFinite(timestamp) || timestamp > now) return 'unverified'
  if (now - timestamp > 5 * 60_000) return 'stale'
  if (run.summary !== undefined && (!run.summary || typeof run.summary !== 'object' || Array.isArray(run.summary))) return 'unverified'
  if (run.steps !== undefined && (!Array.isArray(run.steps) || run.steps.some(step => !step || typeof step !== 'object'))) return 'unverified'
  if (run.errors !== undefined && (!Array.isArray(run.errors) || run.errors.some(error => typeof error !== 'string'))) return 'unverified'
  if (run.ok === false || run.summary?.ok === false || run.steps?.some(step => step.ok === false) || run.errors?.length) return 'failed'
  if (run.ok !== true && run.summary?.ok !== true) return 'unverified'
  const paper = run.live === false || ['paper', 'shadow'].includes(run.summary?.mode || '')
  if (run.live === true && paper) return 'unverified'
  return run.live === true ? 'live_declared' : paper ? 'paper_declared' : 'unverified'
}

function bases(): string[] {
  const list: string[] = []
  if (typeof window !== 'undefined') {
    list.push(`${window.location.origin}${import.meta.env.BASE_URL || '/'}data/`)
  }
  list.push('https://neltud.github.io/xArtists/data/')
  list.push('/data/')
  return list
}

export async function fetchVellumLastRun(): Promise<VellumLastRun | null> {
  for (const base of bases()) {
    try {
      const url = `${base.replace(/\/?$/, '/')}vellum_last_run.json?t=${Date.now()}`
      const r = await fetch(url, { cache: 'no-store' })
      if (!r.ok) continue
      const j = (await r.json()) as VellumLastRun
      if (j && typeof j === 'object') return j
    } catch {
      /* try next */
    }
  }
  return null
}
