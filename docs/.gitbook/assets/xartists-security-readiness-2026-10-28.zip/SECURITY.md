# Politique de sécurité xArtists

L'état vérifié et les preuves sont dans [le dossier de sécurité](docs/security/README.md). Un site public ou un contrat mainnet ne constitue pas une validation d'ouverture marchande.

Pour une faille exploitable ou une clé exposée, demander au mainteneur **Neltud** un canal privé. Utiliser le signalement privé GitHub s'il est proposé sur la page Security ; son activation n'est pas attestée ici. Ne publier aucun secret, donnée personnelle ou détail d'exploitation dans une issue publique.

Fournir commit, composant, préconditions, impact et reproduction locale avec données fictives. Aucun test ne doit déplacer de fonds ni modifier un contrat ou des données utilisateur.

Le mainteneur désigne un responsable, conserve les preuves sans secrets et fait relire le correctif avec sa régression. Fusion, déploiement, rotation de clé et opération on-chain requièrent les autorisations adaptées. La clôture nomme la version, les contrôles rejoués et les limites.

Les délais de réponse et l'astreinte doivent être acceptés avant une ouverture marchande ; aucun SLA n'est annoncé par ce document.

[Arrêt et reprise](docs/EMERGENCY_PAUSE.md) · [Critères de lancement](docs/security/launch-gates.md)
