# Pack quote — Rule 1

**État vérifié — 28 octobre 2026 : calculateur sandbox, pas devis de paiement exécutable.** Le taux vient encore du body ; le devis n'est ni signé, ni persisté, ni consommé par le paiement. Les prix SC relus restent 10 / 5 / 2,5 EGLD et ne sont pas encore alignés sur les ancres EUR. Une expiration invalide reste à fermer. Voir [prix et livraison](security/pricing-delivery.md) et [audit](security/audit-2026-10-28.md). Aucun tarif ou contrat modifié par cette documentation.

Client prices: **110 / 75 / 50 €** (Pulse / Yield / Sentinel).

## Parity (corrected 2026-10-27)

```
amount_egld = ceil4( amount_eur / rate_eur_per_egld )
```

Margin **4%** is **accounting only** — it must **not** divide the crypto leg (`list/(1.04)` was a parity bug).

- Tolerance ≤ **0.02 €** after ceil  
- TTL **12 min**  
- Server sole authority for amounts  

Module: `services/access-api/src/quote.mjs`  
Tests: `services/access-api/tests/quote_rule1.test.mjs` (incl. parity)

Endpoint: `POST /v1/checkout/quote` `{ "pack_id", "rate_eur_per_egld" }`.
