"""Package the already reviewed documentation and evidence; no network or deployment."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
AUDITED = '352de2dc8abcba08885506e4f5b44e4c67cc5c05'
PATCH_BASE = 'bbd83bf52edc00f6ae82cbfcdf62764abfbb5c47'
PR_HEAD = '21e043d33644da04facab8915ea55827f056d122'

def git(*args, env=None):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=env)

paths = git('diff', '--cached', '--name-only').decode().splitlines()
assert len(paths) == 14 and all(p.endswith('.md') for p in paths), paths
assert not any('node_modules' in p for p in paths)
errors = []
links = 0
for name in paths:
    text = (ROOT / name).read_text()
    if text.count('```') % 2:
        errors.append([name, 'unbalanced code fence'])
    if text.count('{% hint') != text.count('{% endhint %}'):
        errors.append([name, 'unbalanced hint'])
    for target in re.findall(r'\]\(([^)]+)\)', text):
        if target.startswith(('https:', 'http:', '#', '/pages/', '/files/')):
            continue
        target = target.split('#')[0]
        if target:
            links += 1
            if not (ROOT / name).parent.joinpath(target).exists():
                errors.append([name, 'missing relative target', target])
assert not errors, errors
(BASE / 'DOCUMENT_VALIDATION.json').write_text(json.dumps({
    'markdown_files': len(paths), 'relative_links_checked': links,
    'errors': errors, 'application_sources_changed': [],
}, indent=2) + '\n')

patch = git('diff', '--cached', '--binary')
(BASE / 'DOCS_REVIEW.patch').write_bytes(patch)
index = BASE / 'tmp' / 'patch-check.index'
index.parent.mkdir(exist_ok=True)
if index.exists():
    index.unlink()
env = dict(os.environ, GIT_INDEX_FILE=str(index))
git('read-tree', PATCH_BASE, env=env)
subprocess.run(['git', 'apply', '--cached', '--check', str(BASE / 'DOCS_REVIEW.patch')],
               cwd=ROOT, env=env, check=True)
(BASE / 'PATCH_VALIDATION.json').write_text(json.dumps({
    'base_sha': PATCH_BASE, 'command': 'git apply --cached --check DOCS_REVIEW.patch (isolated index)',
    'exit_code': 0, 'shared_index_or_files_modified': False,
}, indent=2) + '\n')

proofs = [
    'README.md', 'API_MAIN.tap', 'FRONT_RELEASE.tap', 'PYTHON_PAYBOX.txt',
    'SECRET_PATTERN_SCAN.json', 'PAGES_PUBLIC_SMOKE.json', 'ONCHAIN_READONLY.json',
    'ONCHAIN_VIEWS.json', 'GITHUB_SNAPSHOT.json', 'INFRA_SNAPSHOT.json',
    'AUTOMATION_REGISTER.json', 'automation-policy.json', 'SECURITY_PROBES.json',
    'RISK_STORE_PROBE.json', 'security-probes.mjs', 'risk-store-probe.py',
    'PR200_FILE_CONCURRENCY.log', 'PR200_LATEST_FILE_CONCURRENCY.log',
    'PR200_LATEST_API.portable.tap', 'PR200_LATEST_REVIEW.json',
    'DOCS_REVIEW.patch', 'DOCUMENT_VALIDATION.json', 'PATCH_VALIDATION.json',
    'DEPENDENCY_REUSE.json', 'AI_REVIEW_SKIP.log', 'NPM_AUDIT_API.json',
    'NPM_AUDIT_FRONT.json', 'SOURCE_MANIFEST.json', 'build-review-kit.py',
    'pr200/orders-under-review.mjs', 'pr200/file-concurrency-probe.mjs',
    'pr200/orders-latest.mjs', 'pr200/package-lock-latest.json',
]
files = {p: (ROOT / p).read_bytes() for p in paths}
files.update({'artifacts/security-readiness-2026-10-28/' + p: (BASE / p).read_bytes()
              for p in proofs})
for name, content in files.items():
    assert not re.search(rb'^-----BEGIN (?:RSA )?PRIVATE KEY-----\r?$', content, re.M), name
    assert not re.search(rb'/workspace/scratch/[a-z0-9]', content), name
    if name.endswith('.json'):
        json.loads(content)

rows = [{'path': name, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
        for name, content in sorted(files.items())]
manifest = {
    'schema': 'xartists.security_review.manifest.v2',
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'audited_main_sha': AUDITED, 'patch_checked_base_sha': PATCH_BASE,
    'pr200_sha': PR_HEAD, 'historical_pr200_sha': 'e206da7cc9b7ac43e98f539cf823271aecad7e39',
    'documents_only_patch': True, 'application_sources_changed': False,
    'raw_local_failure_stack_logs_included': False,
    'manifest_self_and_sha256sums_excluded_from_hash_rows': True, 'files': rows,
}
manifest_data = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
sums = ''.join(r['sha256'] + '  ' + r['path'] + '\n' for r in rows).encode()
(BASE / 'MANIFEST.json').write_bytes(manifest_data)
(BASE / 'SHA256SUMS').write_bytes(sums)
files.update({'MANIFEST.json': manifest_data, 'SHA256SUMS': sums})
archive_path = BASE / 'xartists-security-readiness-2026-10-28.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, content in sorted(files.items()):
        entry = zipfile.ZipInfo(name, date_time=(2026, 10, 28, 8, 30, 0))
        entry.external_attr = 0o100644 << 16
        archive.writestr(entry, content, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for row in rows:
        assert hashlib.sha256(archive.read(row['path'])).hexdigest() == row['sha256']
info = {
    'file': archive_path.name, 'bytes': archive_path.stat().st_size,
    'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    'entries': len(files), 'payload_files': len(rows),
    'integrity': 'all archive payload hashes and ZIP CRC verified',
}
(BASE / 'ARCHIVE_INFO.json').write_text(json.dumps(info, indent=2) + '\n')
print(json.dumps(info, indent=2))
