# Kit de revue sécurité — 28 octobre 2026

Ce lot contient des documents proposés et des preuves d'audit. Aucun correctif applicatif, merge, déploiement, migration, paiement ou transaction réelle n'a été exécuté pour le produire.

## Références

- Code main testé : `352de2dc8abcba08885506e4f5b44e4c67cc5c05`.
- Tip relu ensuite : `bbd83bf52edc00f6ae82cbfcdf62764abfbb5c47`, delta données paper seulement.
- PR #200 actuelle : `21e043d33644da04facab8915ea55827f056d122` ; ancien head `e206da7…` gardé pour comparaison.
- Documentation : `docs/security/`, README racine, SECURITY.md, runbook et compléments existants du même lot.

## Preuves

`API_MAIN.tap` : 59/59 ; `FRONT_RELEASE.tap` : 40/40 ; `PYTHON_PAYBOX.txt` : 7/7. Le premier essai frontend sans esbuild est conservé séparément et ne vaut pas échec applicatif.

`SECURITY_PROBES.json` : 1/7 satisfait, six attentes non satisfaites ; `RISK_STORE_PROBE.json` : état corrompu rechargé sans halt ; `PR200_FILE_CONCURRENCY.log` : défaut historique (une commande sur trois). Au nouveau head 21e043d, `PR200_LATEST_FILE_CONCURRENCY.log` prouve trois sur trois, exit 0 ; `PR200_LATEST_API.portable.tap` conserve 59/61 et deux échecs v2 async. Le log portable normalise le préfixe temporaire du checkout, sans changer les assertions. `PR200_LATEST_REVIEW.json` distingue installation CI EUSAGE et tests locaux avec cache. Les sondes de défaut terminent à 1 quand le défaut existe.

`NPM_AUDIT_*` : audits sans `fix`, sans install ni scripts ; aucune conclusion d'exploitation automatique. `ONCHAIN_*` : lectures publiques seulement. `INFRA_SNAPSHOT.json` : métadonnées et noms de tables, pas de données utilisateur. `SECRET_PATTERN_SCAN.json` : motifs et limites explicites, pas de valeurs de secrets.

`AUTOMATION_REGISTER.json` décrit le rapport quotidien effectivement activé. `automation-policy.json` décrit ses droits et le régime CI proposé. Aucune seconde tâche GitHub, publication ou conversation Grok n'a été activée.

## Reproduction locale des sondes

Installer les dépendances verrouillées de l'API et du frontend dans une copie isolée, avec un runtime Node maintenu ; ne pas définir de credentials réels. Créer un dossier temporaire local et définir `TMPDIR` vers ce dossier si `/tmp` n'existe pas.

```sh
node artifacts/security-readiness-2026-10-28/security-probes.mjs
python3 artifacts/security-readiness-2026-10-28/risk-store-probe.py
node artifacts/security-readiness-2026-10-28/pr200/file-concurrency-probe.mjs artifacts/security-readiness-2026-10-28/pr200/orders-under-review.mjs
```

Le module PR #200 est une copie de revue : ne pas le substituer à `main`. Le script risque redirige l'état vers un fichier temporaire ; aucun signataire n'est appelé. Les sondes browser mockent le réseau. Aucun runbook de mutation n'est exécuté par ces commandes.

Vérifier SHA256SUMS avant de réutiliser le lot et citer le head exact lors d'une passation. Une archive reçue ne prouve pas que ses tests ont été exécutés.
