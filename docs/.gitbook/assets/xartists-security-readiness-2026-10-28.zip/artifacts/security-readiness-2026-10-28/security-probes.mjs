/** Isolated audit probes. No provider, wallet, database or chain calls. */
import fs from 'node:fs'
import assert from 'node:assert/strict'
import { loadSource } from '../../apps/frontend/tests/load-source.mjs'
import { isQuoteExpired } from '../../services/access-api/src/quote.mjs'
import { signJwt, verifyJwt } from '../../services/access-api/src/verifyAccess.mjs'

const results = []
function check(id, expected, observed, note) {
  results.push({ id, expected, observed, pass: Object.is(expected, observed), note })
}

check('quote_invalid_expiry_closed', true, isQuoteExpired({ expires_at: 'not-a-date' }),
  'An invalid date must not leave a quote usable. No payment consumes this calculator yet.')
const values = new Map()
globalThis.sessionStorage = {
  getItem: k => values.get(k) ?? null,
  setItem: (k, v) => values.set(k, String(v)),
  removeItem: k => values.delete(k),
}
globalThis.window = { dispatchEvent() {} }
globalThis.CustomEvent = class { constructor(type, detail) { this.type = type; this.detail = detail } }
const config = loadSource('src/config/contracts.ts')
const runtime = loadSource('src/lib/runtimeCodehash.ts')
const fingerprint = config.UNLOCK_JOBS.map(j => `${j.key}:${j.addr}:${j.expected}`).join('|')
const key = 'xartists_runtime_codehash_v6'
function cache(extra) {
  values.set(key, JSON.stringify({ marketplace: true, refreshedAt: Date.now(), generation: 1, jobsFp: fingerprint, ...extra }))
}
cache({ refreshedAt: Date.now() + 86400000 })
check('runtime_future_observation_closed', false, runtime.runtimeCodehashOk('marketplace'),
  'Client cache integrity check, not an on-chain authorization boundary.')
cache({ jobsFp: undefined })
check('runtime_missing_fingerprint_closed', false, runtime.runtimeCodehashOk('marketplace'),
  'A malformed cache omitting the job fingerprint currently passes.')
cache({})
const resolveFetches = []
globalThis.fetch = () => new Promise(resolve => resolveFetches.push(resolve))
const refresh = runtime.refreshRuntimeCodehashes()
const duringRefresh = runtime.runtimeCodehashOk('marketplace')
for (const resolve of resolveFetches) resolve({ ok: false })
await refresh
check('runtime_pending_refresh_closes_previous_positive', false, duringRefresh,
  'A slow/hanging refresh retains the old positive gate until the whole batch finishes; fetch has no timeout.')
check('runtime_completed_failure_closed', false, runtime.runtimeCodehashOk('marketplace'),
  'The completed failure does clear the gate; existing AND protection remains effective.')

const secret = 'audit-fixture-only-not-a-runtime-secret-2026'
const now = Math.floor(Date.now() / 1000)
check('jwt_wrong_issuer_rejected', null,
  verifyJwt(signJwt({ sub: 'fixture', iss: 'another-service', exp: now + 120 }, secret), secret)?.iss ?? null,
  'Signed with a fixture secret: claim-validation hardening, not a keyless forgery.')
check('jwt_future_nbf_rejected', null,
  verifyJwt(signJwt({ sub: 'fixture', iss: 'xartists-access-api', nbf: now + 60, exp: now + 120 }, secret), secret)?.sub ?? null,
  'The verifier validates MAC/algorithm/exp but not nbf.')

const report = { at: new Date().toISOString(), node: process.version, source_sha: '352de2dc8abcba08885506e4f5b44e4c67cc5c05',
  scope: 'Isolated fixture and mocked browser probes only; no remote writes or transaction', results }
fs.writeFileSync(new URL('./SECURITY_PROBES.json', import.meta.url), JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report, null, 2))
assert.equal(results.filter(x => !x.pass).length, 0, 'Audit hardening expectations are not all satisfied')
