import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'xa-pr200-concurrency-'));
delete process.env.DATABASE_URL;
process.env.PAYBOX_ORDERS_PATH=path.join(temp,'orders.json');
try {
 const {createOrder,loadOrders}=await import(pathToFileURL(process.argv[2]).href);
 const ids=['xa_pr200_a','xa_pr200_b','xa_pr200_c'];
 await Promise.all(ids.map(order_id=>createOrder({order_id,pack_id:'pulse',amount_cents:11000,buyer_address:'erd1'+'a'.repeat(58)})));
 const stored=Object.keys((await loadOrders()).orders).sort();
 const result={scope:'isolated_file_store_only_no_database_no_payment',expected_order_ids:ids,persisted_order_ids:stored,lost_order_ids:ids.filter(x=>!stored.includes(x)),regression_detected:stored.length!==ids.length};
 console.log(JSON.stringify(result,null,2));
 process.exitCode=result.regression_detected?1:0;
} finally {fs.rmSync(temp,{recursive:true,force:true});}
