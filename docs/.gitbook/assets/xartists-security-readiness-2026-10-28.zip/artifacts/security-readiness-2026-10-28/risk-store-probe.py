"""Read an isolated corrupt risk state; never touch the application's real state."""
import datetime
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
os.environ['LIA_LIVE_TRADING'] = '0'
from lia.guardian import risk_enforcer

temporary_root = Path(__file__).parent / 'tmp'
temporary_root.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(dir=temporary_root) as directory:
    risk_enforcer.STATE = Path(directory) / 'risk.json'
    risk_enforcer.STATE.write_text('{corrupt')
    loaded = risk_enforcer._load_state()
    observed = loaded.get('halt') is True
    report = {
        'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_sha': '352de2dc8abcba08885506e4f5b44e4c67cc5c05',
        'expected_halt_on_corrupt_existing_state': True,
        'observed_halt': observed,
        'observed_daily_loss_usd': loaded.get('daily_loss_usd'),
        'observed_tx_count': loaded.get('trades_today'),
        'pass': observed,
        'scope': 'Only _load_state on a temporary file; enforce, signer and broadcast not called',
    }
    (Path(__file__).parent / 'RISK_STORE_PROBE.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    sys.exit(0 if observed else 1)
