# Access API — MoonPay et paiements des packs xArtists

État vérifié au 28 octobre 2026 (`352de2dc…`) : serveur Node SIWX/JWT, signature MoonPay et Paybox sandbox. Livraison NFT **simulée**, aucune ouverture bancaire réelle validée. [Audit actuel](../../docs/security/audit-2026-10-28.md).
Secrets **uniquement ici**, jamais dans le front GitHub Pages.

## Endpoints

| Method | Path | Rôle |
|--------|------|------|
| `POST` | `/moonpay/sign` | Signature serveur MoonPay EGLD ; aucun achat exécuté |
| `GET` | `/health` | Disponibilité de configuration, sans valeur de secret |
| `POST` | `/v1/access/challenge` | Challenge wallet exact, cinq minutes, usage unique |
| `POST` | `/v1/verify-access` | Preuve SIWX puis droits/JWT ; alias `/api/verify-access` |
| `GET` | `/v1/access/introspect` | JWT vérifié côté serveur |
| `POST` | `/v1/checkout/quote` | Calculateur Rule 1 ; taux encore fourni par la requête |
| `POST` | `/v1/checkout/paybox` | Acheteur authentifié, montant serveur ; 501 sans configuration marchand |
| `GET / POST` | `/v1/checkout/paybox/ipn` | Une source brute signée, RSA-SHA256/2048, montant/commande liés et déduplication |
| `GET` | `/v1/checkout/paybox/order/:id` | Lecture réservée au buyer de la commande |

Les fichiers Python historiques ne constituent pas une API de production validée. Le serveur Node courant ne fournit pas de session Stripe.

## Env serveur

```bash
# STRIPE_* restent absents pour cette recette Node.
ACCESS_JWT_SECRET=<secret-aleatoire-serveur>
REQUIRE_SIWX=1
LIA_LIVE_TRADING=0
ACCESS_PUBLIC_BASE=https://neltud.github.io
PAYBOX_SITE=...
PAYBOX_RANG=...
PAYBOX_HMAC_KEY=...
PAYBOX_ENV=preprod   # or prod
CORS_ORIGIN=https://neltud.github.io
PAYBOX_IPN_URL=https://<API-HTTPS>/v1/checkout/paybox/ipn
```

## Front (GitHub Pages build secrets / env)

```bash
VITE_ACCESS_API_BASE=https://access-api.example.com
# optionnel : Stripe Payment Links seulement après preuve de liaison au wallet
VITE_STRIPE_PAYMENT_LINK_PULSE=...
# Paybox désactivé jusqu'au backend HMAC + IPN + mint
VITE_PAYBOX_ENABLED=false
```

## Flux

1. User choisit pack + Stripe ou Paybox dans `PackCheckout`.
2. Front `POST` session avec `pack_id`, `buyer_address` (erd1), **sans montant client**.
3. Le serveur vérifie le buyer et choisit le prix au catalogue avant la session HMAC.
4. IPN **authentifié, idempotent et vérifié** → enregistre le paiement ; `delivery: simulated` ne donne aucun droit de production. Le minter live reste à implémenter.
5. Aucun paiement réel ne doit être activé avant tests d'intégration et preuve de livraison NFT.

Voir aussi `docs/PAYBOX_INTEGRATION.md`.

## MoonPay EGLD

Le serveur Node expose POST `/moonpay/sign` avec un corps JSON `{ "url": "…" }`.
Configurer `MOONPAY_PUBLIC_KEY`, `MOONPAY_SECRET_KEY` (même mode test/live),
`MOONPAY_RETURN_URL` et `CORS_ORIGIN` selon `.env.example`. Le front utilise
`VITE_MOONPAY_API_KEY` et `VITE_ACCESS_API_BASE`. Les clés secrètes restent serveur.
Le signataire valide le domaine MoonPay, les paramètres autorisés, le compte
public marchand et l’URL de retour ; il ne valide pas un paiement.

Tests locaux sans paiement :

```sh
node --test services/access-api/tests/*.test.mjs
```

Le PayBox crypto de `lia/executor/paybox_router.py` est un adaptateur distinct
pour Solana/EVM, sans connecteur externe implémenté ici. L’état de release complet
est détaillé dans `docs/RELEASE_AUDIT_2026-10-21.md`.

## Accès signé TCA

Installer avec `npm ci --ignore-scripts` dans ce dossier, lancer avec `npm start`,
et tester avec `npm test` sur un runtime Node maintenu. Le SDK-core 13.17.2 est verrouillé.
Le challenge est lié au wallet et au texte exact, expire après cinq minutes et
n'est utilisable qu'une fois. Le client signe un objet SDK `Message` ; le serveur
vérifie la signature du message préparé par `MessageComputer`. Le checksum de
l'adresse est vérifié. Une erreur de signature ne consomme pas le challenge.

`REQUIRE_SIWX=1` est la valeur par défaut. Même avec le mode facultatif
`REQUIRE_SIWX=0`, un JWT FULL exige un challenge signé valide. Les JWT expirés,
sans expiration ou avec un MAC incorrect sont rejetés. Le test sur appareil
xPortal réel reste une validation distincte des tests logiciels.

## Persistance et limites actuelles

Sur la référence auditée de `main`, les commandes utilisent un fichier JSON, verrou local mono-hôte et renommage atomique. Cela ne persiste pas sur Render Free après perte du filesystem. La PR #200 Postgres est ouverte et bloquée ; définir `DATABASE_URL` seul ne transforme pas cette version en backend Postgres.

Neon sandbox existe ; neuf tables `neon_auth`, aucune table de commandes visible le 28 octobre. Leur présence ne prouve pas une intégration fonctionnelle avec SIWX. Aucune migration ni lecture de données personnelles n'a été faite pour l'audit.

`ACCESS_PUBLIC_BASE` est l'origine **frontend**. `PAYBOX_IPN_URL` doit viser explicitement l'**API** ; ne pas compter sur le repli vers Pages. Préférer un secret JWT aléatoire d'au moins 32 octets, distinct entre services ; le minimum actuel du code est 16 caractères.

59/59 tests existants passent ; les sondes supplémentaires signalent une expiration invalide non fermée et des claims JWT à renforcer. Le devis reste non signé/non persisté, et son taux n'est pas encore une autorité serveur. Voir [prix et livraison](../../docs/security/pricing-delivery.md).
