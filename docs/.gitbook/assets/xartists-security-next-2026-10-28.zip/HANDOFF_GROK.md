# Reprise Grok — lot suivant préparé le 28 octobre 2026

Base main : `11583286b455732762bb81bbe82190183215382c`. Commit code : `35bbe27cf861add96c2936685e0d30535cc91feb`. Commit documentation : `073e2d22698e918f944d97858791ab45f2db7bd9`. Branche locale : `fix/security-quote-cache-2026-10-28`. Aucun des deux commits n'est poussé.

## Avant toute écriture

Relire le tip de main et de #200 ; vérifier les SHA-256 de SHA256SUMS et les fichiers du manifeste. Un chemin modifié depuis la base nécessite une revue, pas un remplacement forcé. Réserver les chemins avec l'autre agent avant écriture. Ne pas concaténer des extraits ou ressaisir les grands fichiers : utiliser les fichiers complets ou les patchs.

Le lot #200 reste distinct : son correctif local antérieur est `38fcb546e58dd1c996c98101581cc9f11b10e13c` (lock API complet et tests Paybox async). Le refus 403 du connecteur et l'absence de connexion navigateur GitHub ont empêché sa publication. Ne pas annoncer cette PR verte sur la base des tests locaux. Ne pas remplacer le lock API complet par un lock réduit.

## Application du nouveau lot

Créer une branche de revue depuis le main relu. Après contrôle de l'absence de divergence des chemins, appliquer `0001-security.patch`, puis `0002-docs.patch` ; vérifier le résultat et exécuter les suites du rapport. Les fichiers complets sont dans `files/`. Ce lot ne modifie aucun des chemins du correctif local #200. Ne pas l'appliquer automatiquement sur feat/orders-neon-store : revue séparée.

Tests attendus sur cette base : API 68/68, frontend 49/49. Un montage temporaire du correctif #200 avec la nouvelle source et le test devis passe 70/70 sous Node 20 ; ce n'est ni un merge ni une CI distante.

Ouvrir une PR non-draft si la publication est possible. Pas de merge, déploiement, activation payante ou transaction réelle sans GO humain spécifique. Ne pas relancer une connexion GitHub refusée sans nouvelle demande de l'utilisateur.

## Ensuite

1. Journaux de risque : corruption/panne = arrêt, réservation atomique et rapprochement durable des budgets.
2. Sessions JWT : émetteur et nbf validés, SIWX et contrôle buyer conservés.
3. Catalogue unique et devis serveur consommable selon payment-pilot-contract.md.
4. Postgres réel et API HTTPS sandbox ; restauration, callbacks signés et livraison au bon acheteur.

Lire les deux documents et VALIDATION.json pour les limites. La tâche quotidienne de lecture à 08:00 Europe/Paris existe déjà ; ne pas la dupliquer et ne pas envoyer de messages ou posts automatiquement.
