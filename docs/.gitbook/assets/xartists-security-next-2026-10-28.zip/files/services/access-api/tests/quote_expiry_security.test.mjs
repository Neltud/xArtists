import assert from 'node:assert/strict'
import { test } from 'node:test'
import { buildPackQuote, isQuoteExpired, RULE1 } from '../src/quote.mjs'

const NOW = Date.parse('2026-10-28T12:00:00.000Z')
const quoteAt = (now = NOW) => buildPackQuote({ pack_id: 'pulse', rate_eur_per_egld: 12, now })

test('an absent or malformed expiry is unusable, without throwing', () => {
  for (const quote of [null, {}, { expires_at: '' }, { expires_at: 'not-a-date' },
    { expires_at: 42 }, { expires_at: [] }, { expires_at: {} }]) {
    assert.equal(isQuoteExpired(quote, NOW), true, JSON.stringify(quote))
  }
})

test('a malformed verification clock cannot extend a quote', () => {
  for (const now of [NaN, Infinity, -Infinity, null, '2026-10-28', -1]) {
    assert.equal(isQuoteExpired(quoteAt(), now), true, String(now))
  }
})

test('a quote is usable before expiry and closes exactly at the 12 minute boundary', () => {
  const quote = quoteAt()
  assert.equal(isQuoteExpired(quote, NOW), false)
  assert.equal(isQuoteExpired(quote, NOW + RULE1.quoteTtlMs - 1), false)
  assert.equal(isQuoteExpired(quote, NOW + RULE1.quoteTtlMs), true)
})

test('an expiry outside the maximum TTL or without a timezone is unusable', () => {
  for (const expires_at of [
    new Date(NOW + RULE1.quoteTtlMs + 1).toISOString(),
    '2026-10-28T12:10:00',
    '2026-02-30T12:10:00.000Z',
  ]) assert.equal(isQuoteExpired({ expires_at }, NOW), true, expires_at)
})

test('future, reversed or malformed issuance dates cannot validate a quote', () => {
  for (const created_at of [
    new Date(NOW + 1).toISOString(),
    new Date(NOW + RULE1.quoteTtlMs + 1).toISOString(),
    'not-a-date', null,
  ]) assert.equal(isQuoteExpired({ ...quoteAt(), created_at }, NOW), true, String(created_at))
})

test('an altered quote lifetime cannot exceed 12 minutes after issuance', () => {
  const quote = quoteAt(NOW - 1000)
  quote.expires_at = new Date(NOW + RULE1.quoteTtlMs).toISOString()
  assert.equal(isQuoteExpired(quote, NOW), true)
})

test('epoch zero is an explicit issuance time, not a request to use the current clock', () => {
  const quote = quoteAt(0)
  assert.equal(quote.created_at, '1970-01-01T00:00:00.000Z')
  assert.equal(quote.expires_at, '1970-01-01T00:12:00.000Z')
})

test('invalid issuance clocks produce a controlled error before a quote is returned', () => {
  for (const now of [NaN, Infinity, -Infinity, -1, null, '42', 1.5, 8.64e15]) {
    assert.throws(() => quoteAt(now), { message: 'invalid_quote_time', statusCode: 400 }, String(now))
  }
})

test('expiry validation never changes the approved customer prices, rounding or internal margin', () => {
  for (const [pack_id, cents] of [['pulse', 11000], ['yield', 7500], ['sentinel', 5000]]) {
    const quote = buildPackQuote({ pack_id, rate_eur_per_egld: 12, now: NOW })
    assert.equal(quote.amount_cents, cents)
    assert.equal(quote.margin_internal, 0.04)
    assert.ok(quote.amount_egld * 12 >= cents / 100)
    assert.ok(quote.rounding_gap_eur <= 0.02)
    assert.equal(isQuoteExpired(quote, NOW), false)
  }
})
