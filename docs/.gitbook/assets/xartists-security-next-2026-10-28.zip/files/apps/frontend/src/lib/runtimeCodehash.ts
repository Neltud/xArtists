/**
 * Runtime codeHash observation; fund-moving UI gates also require their build flag.
 * Fail-closed: missing explorer data or a pending refresh = locked.
 * Freshness: a prior true cache cannot reopen after a later failed refresh.
 * Source: config/contracts.ts (hashes vérifiés 2026-10-01).
 */

import { UNLOCK_JOBS, type UnlockKey } from '../config/contracts'

export type { UnlockKey }

const STORAGE = 'xartists_runtime_codehash_v6'

type Cache = Partial<Record<UnlockKey, boolean>> & {
  slotBalance?: number
  /** Epoch ms of last successful full refresh write */
  refreshedAt?: number
  /** Monotonic generation; bumps on every refresh attempt */
  generation?: number
  /** Fingerprint of UNLOCK_JOBS addresses/hashes — invalidates on config change */
  jobsFp?: string
}

// Keep the newest observation even when sessionStorage is unavailable or full.
// The generation is process-local: persisted input cannot decide which request wins.
let currentCache: Cache | null = null
let refreshGeneration = 0

function readCache(): Cache {
  if (currentCache) return currentCache
  try {
    const raw = sessionStorage.getItem(STORAGE)
    if (!raw) return {}
    const parsed: unknown = JSON.parse(raw)
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed as Cache : {}
  } catch {
    return {}
  }
}

function writeCache(c: Cache) {
  currentCache = { ...c }
  try {
    sessionStorage.setItem(STORAGE, JSON.stringify(c))
  } catch {
    /* */
  }
}

/** Max age for a positive observation (ms). Stale cache never opens gates. */
export const RUNTIME_CODEHASH_MAX_AGE_MS = 5 * 60 * 1000
/** Bounds both the account request and response-body read. */
export const RUNTIME_CODEHASH_FETCH_TIMEOUT_MS = 8_000

function jobsFingerprint(): string {
  return UNLOCK_JOBS.map(j => `${j.key}:${j.addr}:${j.expected}`).join('|')
}

/**
 * True only when this key was observed true on a fresh refresh for the current job set.
 * Missing refresh / false / absent / stale / address change → not ok (fail-closed).
 */
export function runtimeCodehashOk(key: UnlockKey): boolean {
  const c = readCache()
  if (typeof c.refreshedAt !== 'number' || !Number.isFinite(c.refreshedAt) || c.refreshedAt <= 0) return false
  const age = Date.now() - c.refreshedAt
  if (!Number.isFinite(age) || age < 0 || age > RUNTIME_CODEHASH_MAX_AGE_MS) return false
  if (c.jobsFp !== jobsFingerprint()) return false
  return c[key] === true
}

export function runtimeSlotBalance(): number {
  const balance = readCache().slotBalance
  return typeof balance === 'number' && Number.isFinite(balance) && balance >= 0 ? balance : 0
}

export function runtimeUnlockSnapshot(): Cache {
  return { ...readCache() }
}

export function runtimeRefreshGeneration(): number {
  const generation = readCache().generation
  return Number.isSafeInteger(generation) && Number(generation) >= 0 ? Number(generation) : 0
}

type Account = { codeHash?: unknown; balance?: unknown; isPayable?: unknown }

async function fetchAccount(
  addr: string,
): Promise<Account | null> {
  if (!addr?.startsWith('erd1')) return null
  const controller = new AbortController()
  let timer: ReturnType<typeof setTimeout> | undefined
  try {
    const request = (async () => {
      const r = await fetch(`https://api.multiversx.com/accounts/${addr}`, {
        cache: 'no-store', signal: controller.signal,
      })
      if (!r.ok) return null
      const account: unknown = await r.json()
      return account && typeof account === 'object' && !Array.isArray(account) ? account as Account : null
    })()
    const deadline = new Promise<null>(resolve => {
      timer = setTimeout(() => {
        controller.abort()
        resolve(null)
      }, RUNTIME_CODEHASH_FETCH_TIMEOUT_MS)
    })
    // The race also settles if a transport ignores abort or JSON reading stalls.
    return await Promise.race([request, deadline])
  } catch {
    return null
  } finally {
    if (timer !== undefined) clearTimeout(timer)
  }
}

function matchHash(expected: string, got?: unknown): boolean {
  if (typeof got !== 'string' || !got || !expected) return false
  return got === expected || got.replace(/=+$/, '') === expected.replace(/=+$/, '')
}

function publishCache(cache: Cache): void {
  writeCache(cache)
  try {
    window.dispatchEvent(new CustomEvent('xartists-codehash', { detail: { ...cache } }))
  } catch {
    /* */
  }
}

/**
 * Refresh unlocks from on-chain reads only.
 * Always rewrites the whole cache: a previous true cannot survive a failed observation.
 * Concurrent: claim generation first; a late success never overwrites a newer failure.
 */
export async function refreshRuntimeCodehashes(): Promise<Cache> {
  const generation = ++refreshGeneration
  const startedAt = Date.now()
  const cache: Cache = { generation, jobsFp: jobsFingerprint() }
  // Revoke every previous positive before any network work, including UI subscribers.
  publishCache(cache)

  await Promise.all(
    UNLOCK_JOBS.map(async j => {
      const acc = await fetchAccount(j.addr)
      if (!acc) {
        cache[j.key] = false
        return
      }
      const okHash = matchHash(j.expected, acc.codeHash)
      if (j.key === 'slot') {
        const bal = Number(acc.balance ?? 0) / 1e18
        cache.slotBalance = Number.isFinite(bal) && bal >= 0 ? bal : 0
        // Hash match is not enough: isPayable=false rejects spinEgld.
        cache.slot = okHash && acc.isPayable === true && Number.isFinite(bal) && bal >= 0
      } else {
        cache[j.key] = okHash
      }
    }),
  )

  // Discard if a newer refresh already committed (stale success must not erase recent failure)
  if (generation !== refreshGeneration) {
    return { ...readCache() }
  }
  cache.refreshedAt = startedAt
  publishCache(cache)
  return { ...cache }
}
