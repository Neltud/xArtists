/** Test the shipped runtime module with mocked explorer responses. No network or wallet. */
import assert from 'node:assert/strict'
import { test } from 'node:test'
import { loadSource } from './load-source.mjs'

const STORAGE = 'xartists_runtime_codehash_v6'
const NOW = Date.parse('2026-10-28T12:00:00.000Z')
const config = loadSource('src/config/contracts.ts')
const fingerprint = config.UNLOCK_JOBS.map(j => `${j.key}:${j.addr}:${j.expected}`).join('|')
const validCache = extra => ({ marketplace: true, refreshedAt: NOW - 1000, generation: 1, jobsFp: fingerprint, ...extra })

async function withRuntime(cache, run, options = {}) {
  const names = ['fetch', 'sessionStorage', 'window', 'CustomEvent', 'setTimeout', 'clearTimeout']
  const originals = new Map(names.map(name => [name, Object.getOwnPropertyDescriptor(globalThis, name)]))
  const originalNow = Date.now
  const values = new Map([[STORAGE, typeof cache === 'string' ? cache : JSON.stringify(cache)]])
  const events = []
  const timers = new Map()
  let timerId = 0
  Date.now = () => NOW
  globalThis.sessionStorage = {
    getItem: key => values.get(key) ?? null,
    setItem: (key, value) => {
      if (options.writeFails) throw new Error('storage_unavailable')
      values.set(key, String(value))
    },
  }
  globalThis.window = { dispatchEvent: event => events.push(event) }
  globalThis.CustomEvent = class { constructor(type, init) { this.type = type; this.detail = init.detail } }
  globalThis.setTimeout = (fn, ms) => { const id = ++timerId; timers.set(id, { fn, ms }); return id }
  globalThis.clearTimeout = id => timers.delete(id)
  globalThis.fetch = () => assert.fail('an unmocked network call was attempted')
  try {
    await run(loadSource('src/lib/runtimeCodehash.ts'), { values, events, timers })
  } finally {
    Date.now = originalNow
    for (const [name, descriptor] of originals) {
      if (descriptor) Object.defineProperty(globalThis, name, descriptor)
      else delete globalThis[name]
    }
  }
}

const matching = url => {
  const job = config.UNLOCK_JOBS.find(j => String(url).endsWith('/' + j.addr))
  assert.ok(job, String(url))
  return { ok: true, json: async () => ({ codeHash: job.expected, balance: '1000000000000000000', isPayable: true }) }
}

test('fresh matching cached observations are usable only within their TTL', async () => {
  await withRuntime(validCache({}), runtime => assert.equal(runtime.runtimeCodehashOk('marketplace'), true))
  await withRuntime(validCache({ refreshedAt: NOW - 300001 }), runtime => assert.equal(runtime.runtimeCodehashOk('marketplace'), false))
})

test('future observations and invalid timestamps are closed', async () => {
  for (const refreshedAt of [NOW + 1, 'today', null, 0]) {
    await withRuntime(validCache({ refreshedAt }), runtime => assert.equal(runtime.runtimeCodehashOk('marketplace'), false))
  }
})

test('missing, empty and changed fingerprints cannot reuse a positive cache', async () => {
  for (const jobsFp of [undefined, '', 'old-configuration']) {
    await withRuntime(validCache({ jobsFp }), runtime => assert.equal(runtime.runtimeCodehashOk('marketplace'), false))
  }
})

test('malformed JSON, null and arrays fail closed without crashing the UI', async () => {
  for (const cache of ['{broken', 'null', '[]', '42']) {
    await withRuntime(cache, runtime => assert.equal(runtime.runtimeCodehashOk('marketplace'), false))
  }
})

test('starting a refresh immediately revokes the previous positive and notifies the UI', () =>
  withRuntime(validCache({}), async (runtime, { events }) => {
    const pending = []
    globalThis.fetch = () => new Promise(resolve => pending.push(resolve))
    const refreshing = runtime.refreshRuntimeCodehashes()
    const duringRefresh = runtime.runtimeCodehashOk('marketplace')
    const notified = events[0]?.type
    for (const resolve of pending) resolve({ ok: false })
    await refreshing
    assert.equal(duringRefresh, false)
    assert.equal(notified, 'xartists-codehash')
    assert.equal(runtime.runtimeCodehashOk('marketplace'), false)
  }))

test('all fresh matches reopen runtime checks and clear every deadline', () =>
  withRuntime({}, async (runtime, { timers }) => {
    globalThis.fetch = async url => matching(url)
    await runtime.refreshRuntimeCodehashes()
    for (const { key } of config.UNLOCK_JOBS) assert.equal(runtime.runtimeCodehashOk(key), true, key)
    assert.equal(runtime.runtimeSlotBalance(), 1)
    assert.equal(timers.size, 0)
  }))

test('slot remains closed when isPayable is false despite a matching hash', () =>
  withRuntime({}, async runtime => {
    globalThis.fetch = async url => {
      const response = matching(url)
      const account = await response.json()
      return { ok: true, json: async () => ({ ...account, isPayable: false }) }
    }
    await runtime.refreshRuntimeCodehashes()
    assert.equal(runtime.runtimeCodehashOk('slot'), false)
    assert.equal(runtime.runtimeCodehashOk('marketplace'), true)
  }))

test('a newer failed refresh beats an older successful response', () =>
  withRuntime({}, async runtime => {
    const older = []
    globalThis.fetch = url => new Promise(resolve => older.push(() => resolve(matching(url))))
    const first = runtime.refreshRuntimeCodehashes()
    globalThis.fetch = async () => ({ ok: false })
    await runtime.refreshRuntimeCodehashes()
    for (const resolve of older) resolve()
    await first
    assert.equal(runtime.runtimeRefreshGeneration(), 2)
    assert.equal(runtime.runtimeCodehashOk('marketplace'), false)
  }))

test('a stalled fetch is bounded even if the transport ignores abort, and late success cannot reopen it', () =>
  withRuntime(validCache({}), async (runtime, { timers }) => {
    const pending = []
    const signals = []
    globalThis.fetch = (url, options) => {
      signals.push(options.signal)
      return new Promise(resolve => pending.push(() => resolve(matching(url))))
    }
    const refreshing = runtime.refreshRuntimeCodehashes()
    if (timers.size !== config.UNLOCK_JOBS.length) {
      for (const resolve of pending) resolve()
      await refreshing
      assert.fail('each account read must have an explicit deadline')
    }
    for (const timer of [...timers.values()]) {
      assert.equal(timer.ms, runtime.RUNTIME_CODEHASH_FETCH_TIMEOUT_MS)
      timer.fn()
    }
    await refreshing
    assert.ok(signals.every(signal => signal.aborted))
    assert.equal(runtime.runtimeCodehashOk('marketplace'), false)
    for (const resolve of pending) resolve()
    await Promise.resolve()
    await Promise.resolve()
    assert.equal(runtime.runtimeCodehashOk('marketplace'), false)
    assert.equal(timers.size, 0)
  }))

test('the same deadline covers a response body that never arrives', () =>
  withRuntime({}, async (runtime, { timers }) => {
    if (!runtime.RUNTIME_CODEHASH_FETCH_TIMEOUT_MS) assert.fail('missing response-body deadline')
    globalThis.fetch = async () => ({ ok: true, json: () => new Promise(() => {}) })
    const refreshing = runtime.refreshRuntimeCodehashes()
    await Promise.resolve()
    for (const timer of [...timers.values()]) timer.fn()
    await refreshing
    assert.equal(runtime.runtimeCodehashOk('marketplace'), false)
    assert.equal(timers.size, 0)
  }))

test('failed storage writes cannot resurrect the old positive in the active document', () =>
  withRuntime(validCache({}), async runtime => {
    globalThis.fetch = async () => ({ ok: false })
    await runtime.refreshRuntimeCodehashes()
    assert.equal(runtime.runtimeCodehashOk('marketplace'), false)
  }, { writeFails: true }))

test('bad explorer shapes and a non-string code hash close the relevant gates', () =>
  withRuntime({}, async runtime => {
    for (const account of [null, [], { codeHash: 42 }, { codeHash: {} }]) {
      globalThis.fetch = async () => ({ ok: true, json: async () => account })
      await runtime.refreshRuntimeCodehashes()
      assert.equal(runtime.runtimeCodehashOk('marketplace'), false)
    }
  }))

test('callers cannot mutate the internal snapshot to reopen an observed failure', () =>
  withRuntime({}, async runtime => {
    globalThis.fetch = async () => ({ ok: false })
    const result = await runtime.refreshRuntimeCodehashes()
    result.marketplace = true
    runtime.runtimeUnlockSnapshot().marketplace = true
    assert.equal(runtime.runtimeCodehashOk('marketplace'), false)
  }))

test('the actual marketplace gate requires both its build flag and a valid runtime observation', async () => {
  for (const [cache, buildFlag, expected] of [
    [validCache({}), '1', true],
    [validCache({}), '0', false],
    [validCache({ refreshedAt: NOW + 1 }), '1', false],
    [validCache({ jobsFp: undefined }), '1', false],
  ]) {
    await withRuntime(cache, () => {
      const gates = loadSource('src/config/scStatus.ts', { VITE_MARKETPLACE_CODEHASH_OK: buildFlag })
      assert.equal(gates.canListBuyNft(), expected)
    })
  }
})
