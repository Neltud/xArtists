# Fermer les devis invalides et révoquer les observations runtime en attente

Une expiration de devis invalide passait le contrôle de temps ; un cache de contrat futur ou sans empreinte pouvait ouvrir une action UI. Un rafraîchissement réseau bloqué conservait aussi une ancienne observation positive.

Le correctif valide les horloges et la durée de vie des devis, exige une empreinte runtime exacte, révoque les observations au démarrage du refresh et borne la requête et son corps JSON à huit secondes. Les tests importent les modules réellement utilisés ; la concurrence et les pannes de stockage sont couvertes.

Validation locale Node 20 : API 68/68, frontend 49/49 ; Python Paybox 7/7 ; trading gates, routes, build et verify:site verts. Montage isolé avec le correctif PR200 non publié : API 70/70. Aucune CI distante n'a exécuté ces commits.

Prix et contrats non modifiés. Le cache UI ne remplace pas l'autorisation serveur ; le devis reste un calculateur sans taux serveur ni consommation durable. Pas de test Postgres réel ou de parcours wallet sur appareil. Chunks frontend encore volumineux.

Les deux pages de préparation décrivent la reprise Grok et le contrat du pilote paiement/livraison. Budget 0 EUR ; paper/sandbox ; aucun merge ou déploiement sans GO humain.
