import assert from 'node:assert/strict'
import { test } from 'node:test'
import { loadSource } from './load-source.mjs'

const { askMentor } = loadSource('src/lib/tcaRag.ts')
const unavailable = result => {
  assert.match(result.answer, /do not find/i)
  assert.equal(result.cite, undefined)
  assert.equal(result.visual_ref, undefined)
  assert.equal(result.emotion, 'thinking')
  assert.ok(result.cues.some(cue => cue.type === 'DYNAMIC_TEXT' && cue.payload.text === result.answer))
}
const notes = [
  { id: 'a', lesson_id: 'lesson-a', text: 'Sfumato study from lesson A.', concept: 'sfumato', cite: 'fixture A', professors: ['leonardo'] },
  { id: 'b', lesson_id: 'lesson-b', text: 'Geometry study from lesson B.', concept: 'geometry', cite: 'fixture B', professors: ['turner'] },
]

test('an unknown question returns an honest unsupported response without overflowing the stack', () => {
  unavailable(askMentor('zyxv998877', 'leonardo'))
})

test('an empty knowledge base returns no invented answer or citation', () => {
  unavailable(askMentor('sfumato', 'leonardo', []))
})

test('an empty question is bounded with or without a professor filter', () => {
  unavailable(askMentor('', 'leonardo', notes))
  unavailable(askMentor('', '', notes))
})

test('supported questions preserve the matching knowledge and citation', () => {
  const answer = askMentor('sfumato', 'leonardo', notes)
  assert.equal(answer.answer, 'Sfumato study from lesson A.')
  assert.equal(answer.cite, 'fixture A')
})

test('a professor mismatch can relax once and still return the matching source', () => {
  const answer = askMentor('sfumato', 'other-professor', notes)
  assert.equal(answer.cite, 'fixture A')
  assert.match(answer.answer, /lesson A/)
})

test('a selected lesson keeps its own answer and does not mix in another lesson', () => {
  const answer = askMentor('sfumato', 'leonardo', notes, { lesson_id: 'lesson-a' })
  assert.equal(answer.cite, 'fixture A')
  assert.doesNotMatch(answer.answer, /lesson B/)
})

test('a question outside the selected lesson does not escape to another lesson with a matching answer', () => {
  unavailable(askMentor('geometry', 'leonardo', notes, { lesson_id: 'lesson-a' }))
})
