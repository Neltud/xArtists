Une question inconnue dans le mentor TCA relançait indéfiniment la recherche sans filtre et finissait en débordement de pile. Le correctif relâche le filtre professeur une seule fois, puis laisse le chemin existant répondre qu'aucune note ne correspond. Les réponses connues, citations et contextes de leçon sont conservés.

Validation locale Node 20 : 7/7 scénarios dédiés, 47/47 frontend, build et verify:site verts. Montage local avec le correctif cache/devis : 56/56 frontend. Pas de CI distante pour ces commits.

La documentation prépare le rôle du copilote LIA, un contrat de proposition sans exécution, quatre masterclasses TCA Academy et le conducteur original du premier cours. Les connexions de la conversation ne sont pas des intégrations déjà déployées. Budget 0 EUR, vidIQ 0 crédit consommé, aucune publication média, reconfiguration Vellum ou opération financière.
