# Correctif EGLD live + WHOOP privé — 29 octobre 2026

Correctif testé localement, non poussé et non déployé. Le push GitHub n’a pas de credentials disponibles dans cet environnement. Le kit contient uniquement le diff, le manifeste et les consignes ; aucun secret réel ni donnée de santé réelle.

## Appliquer via un accès GitHub autorisé

Depuis le dépôt à jour, ouvrir une branche dédiée. Base testée : `1a17877fc8334c964e613c8616410aca62bcf775`.

```sh
git switch -c fix/live-egld-private-whoop-20261029
git apply --check live-egld-private-whoop.patch
git apply live-egld-private-whoop.patch
```

Si le contrôle échoue parce que main a avancé, adapter le diff à la version courante en préservant les autres travaux ; ne pas forcer ni écraser main.

Exécuter `npm test` dans `services/access-api`, puis `npm run test:release` et `npm run build` dans `apps/frontend`. Validation locale : 73 tests API et 44 tests frontend passent ; build Vite réussi. Le typecheck global est déjà rouge dans la base : comparaison avant/après faite, aucun nouveau diagnostic. Publier une PR avec le SHA, les résultats et cette limite.

Après intégration et déploiement API + Pages : vérifier `/health` (`fx_mode: live`) et `/v1/market/egld`, les quotes et leur champ `fx.as_of`. Retirer alors les anciennes variables de taux fixes. Une indisponibilité marché doit rendre 503, jamais 3.24 ou un prix de cache indéfini.

WHOOP reste désactivé par défaut. Lire `services/access-api/WHOOP_AND_LIVE_FX.md`, appliquer la migration 002, configurer l’app OAuth et les secrets serveur, puis recueillir le consentement réel. Le JWT doit porter la méthode SIWX signée par le serveur ; les anciennes sessions demandent une nouvelle signature. Ne pas annoncer la connexion WHOOP validée sur la seule base des tests avec fixtures.

Les identifiants marchand PayBox LIVE restent nécessaires ; ce kit ne les contient pas et ne bascule pas PayBox en prod. Aucun paiement réel ni broadcast de transaction n’a été exécuté.
