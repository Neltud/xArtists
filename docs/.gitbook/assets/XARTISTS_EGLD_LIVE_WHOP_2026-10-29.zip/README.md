# EGLD marché + passation Whop — correction du 29 octobre 2026

Nelson demande **Whop commerce**, comme dans sa capture PayBox Markets. L’ancien kit WHOOP santé est annulé. Ce kit remplace ce livrable ; il ne contient ni panneau santé, ni OAuth WHOOP, ni migration de données de santé.

Le code livré concerne uniquement le cours EGLD de marché horodaté. Le document `services/access-api/LIVE_FX_AND_WHOP.md`, inclus dans le patch, prépare la reprise Whop. Il distingue PayBox Markets de MoonPay du checkout carte Paybox Verifone et ne prétend pas qu’un catalogue Whop ou un compte réel a été connecté.

## Application

Le push reste bloqué faute d’identifiant GitHub d’écriture disponible. Base testée : `1a17877fc8334c964e613c8616410aca62bcf775`. Depuis main relu avec un accès autorisé :

```sh
git switch -c fix/live-egld-market-20261029
git apply --check live-egld-market.patch
git apply live-egld-market.patch
```

Si main a changé, adapter sans écraser les autres travaux. Rejouer les tests et ouvrir la PR. Les changements GitBook de documentation sur main ne déploient pas le code API/frontend.

## Vérifications

66 tests API, 42 tests frontend et build Vite passent. Le typecheck complet conserve les mêmes erreurs que la base, sans nouveau diagnostic. Dans un environnement sans `/tmp` accessible, définir TMPDIR vers un répertoire de travail accessible avant les tests API.

Après intégration et déploiement API + Pages : vérifier `/health` (`fx_mode: live`), `/v1/market/egld` et les quotes avec `fx.as_of`. Retirer alors les variables de taux fixes. Une panne marché doit produire une indisponibilité explicite ; aucun prix fixe de secours.

Pour Whop, reprendre depuis les outils officiels PayBox exposés par le host, découvrir le plugin et son contrat réel, puis consulter un article et son prix courant. Un achat exige la confirmation de l’article, du total et du règlement, puis l’approbation passkey de l’utilisateur. Aucun achat n’a été initié.

Les secrets Verifone LIVE restent nécessaires à la bascule indépendante du checkout carte. Aucun paiement réel ou broadcast LIA n’a été effectué.
